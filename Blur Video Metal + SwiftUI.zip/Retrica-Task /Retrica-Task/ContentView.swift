//
//  ContentView.swift
//  Retrica-Task
//
//  Created by Yugantar Jain on 09/12/20.
//

import SwiftUI
import AVKit

struct ContentView: View {
    @State private var showVideoSelector = false
    @State private var videoURL: URL? = nil
    @State private var blurStrength: Float = 10
    @State private var location: CGPoint = CGPoint(x: 100, y: 100)
    
    let pointToPixelScale = UIScreen.main.scale
    var squareSide: CGFloat {
        return 80 / pointToPixelScale
    }
    var halfOfSquareSide: CGFloat {
        return squareSide / 2
    }
    
    var body: some View {
        Group {
            if let url = videoURL {
                ZStack {
                    MetalVideoView(videoURL: url, blurRadius: blurStrength, originX: location.x - 40, originY: location.y - 40)
                    
                    VStack {
                        Spacer()
                        Slider(value: $blurStrength, in: 10...80)
                    }
                    .padding(50)
                    
                    Rectangle()
                        .opacity(0.001)
                        .frame(width: squareSide, height: squareSide)
                        .border(Color.white, width: CGFloat(2/pointToPixelScale))
                        .position(location)
                        .gesture(
                            DragGesture()
                                .onChanged { value in
                                    if value.location.x < halfOfSquareSide {
                                        location.x = halfOfSquareSide
                                    } else if value.location.x > UIScreen.main.bounds.width - halfOfSquareSide {
                                        location.x = UIScreen.main.bounds.width - halfOfSquareSide
                                    } else {
                                        location.x = value.location.x
                                    }

                                    if value.location.y < halfOfSquareSide {
                                        location.y = halfOfSquareSide
                                    } else if value.location.y > UIScreen.main.bounds.height - halfOfSquareSide {
                                        location.y = UIScreen.main.bounds.height - halfOfSquareSide
                                    } else {
                                        location.y = value.location.y
                                    }
                                }
                        )
                }
            } else {
                Button("Select Video") {
                    showVideoSelector.toggle()
                }
                .font(.largeTitle)
            }
        }
        .ignoresSafeArea()
        .sheet(isPresented: $showVideoSelector) {
            VideoPicker(videoURL: $videoURL)
        }
    }
}
