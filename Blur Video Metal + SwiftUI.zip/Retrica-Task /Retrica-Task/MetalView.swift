//
//  MetalView.swift
//  Retrica-Task
//
//  Created by Yugantar Jain on 12/12/20.
//

import MetalKit
import SwiftUI
import AVFoundation

struct MetalVideoView: UIViewRepresentable {
    var videoURL: URL
    var blurRadius: Float
    var originX: CGFloat
    var originY: CGFloat
    let metalVideoView = BlurredVideoMetalView()
    
    func makeUIView(context: UIViewRepresentableContext<MetalVideoView>) -> MTKView {
        metalVideoView.play(stream: videoURL, withBlur: blurRadius, squareOrigin: CGPoint(x: originX, y: originY))
        return metalVideoView
    }
    
    func updateUIView(_ UIView: MTKView, context: UIViewRepresentableContext<MetalVideoView>) {
        context.coordinator.setBlurParameters(radius: blurRadius, squareOrigin: CGPoint(x: originX, y: originY))
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(view: metalVideoView)
    }
    
    class Coordinator {
        let view: BlurredVideoMetalView
        
        init(view: BlurredVideoMetalView) {
            self.view = view
        }
        
        func setBlurParameters(radius: Float, squareOrigin: CGPoint) {
            view.blurRadius = radius
            view.squareOrigin = squareOrigin
        }
    }
}

class BlurredVideoMetalView: MTKView {
    var player: AVPlayer!
    var blurRadius: Float!
    var squareOrigin: CGPoint!
    
    struct BlurParameters {
        var radius: Float
        var originX: Float
        var originY: Float
    }
    var blurParameters: BlurParameters!
    
    let pointToPixelScale = UIScreen.main.scale
    var squareSide: CGFloat {
        return 80 / pointToPixelScale
    }
    
    private var output: AVPlayerItemVideoOutput!
    private var displayLink: CADisplayLink!
    private var playerItemObserver: NSKeyValueObservation?
    private var imageTexture: MTLTexture!
    private var computePipelineState: MTLComputePipelineState!
    private var computePipelineState2: MTLComputePipelineState!
    private var computePipelineState3: MTLComputePipelineState!

    private let colorSpace = CGColorSpaceCreateDeviceRGB()
    private lazy var commandQueue: MTLCommandQueue? = {
        return self.device!.makeCommandQueue()
    }()
    
    private lazy var content: CIContext = {
        return CIContext(mtlDevice: self.device!, options: [CIContextOption.workingColorSpace : NSNull()])
    }()
    
    private var orientation: AVAsset.VideoOrientation = .right
    
    private var image: CGImage? {
        didSet {
            draw()
        }
    }
    
    override init(frame frameRect: CGRect, device: MTLDevice?) {
        super.init(frame: frameRect, device: device ?? MTLCreateSystemDefaultDevice())
        setup()
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        device = MTLCreateSystemDefaultDevice()
        setup()
    }
    
    private func setup() {
        framebufferOnly = false
        isPaused = false
        enableSetNeedsDisplay = false
        preferredFramesPerSecond = 60
        
        let library = device?.makeDefaultLibrary()
        
        // Shader Functions
        func makeComputePipelineStatesForShaders() {
            let shaderFunction = library?.makeFunction(name: "verticalBlur")
            do {
                try computePipelineState = device?.makeComputePipelineState(function: shaderFunction!)
            } catch {
                print(error)
            }
            
            let shaderFunction2 = library?.makeFunction(name: "horizontalBlur")
            do {
                try computePipelineState2 = device?.makeComputePipelineState(function: shaderFunction2!)
            } catch {
                print(error)
            }
            
            let shaderFunction3 = library?.makeFunction(name: "sharpImage")
            do {
                try computePipelineState3 = device?.makeComputePipelineState(function: shaderFunction3!)
            } catch {
                print(error)
            }
        }
        makeComputePipelineStatesForShaders()
    }
    
    func play(stream: URL, withBlur blur: Float, squareOrigin: CGPoint, completion: (()->Void)? = nil) {
        layer.isOpaque = true
        blurRadius = blur
        self.squareOrigin = squareOrigin
                
        let item = AVPlayerItem(url: stream)
        orientation = item.asset.videoOrientation() ?? .right
        output = AVPlayerItemVideoOutput(outputSettings: nil)
        item.add(output)
        
        playerItemObserver = item.observe(\.status) { [weak self] item, _ in
            guard item.status == .readyToPlay else { return }
            self?.playerItemObserver = nil
            self?.setupDisplayLink()
            
            self?.player.play()
            completion?()
        }
        
        player = AVPlayer(playerItem: item)
    }
    
    private func setupDisplayLink() {
        displayLink = CADisplayLink(target: self, selector: #selector(displayLinkUpdated(link:)))
        displayLink.preferredFramesPerSecond = 60
        displayLink.add(to: .main, forMode: RunLoop.Mode.common)
    }
    
    private func fixImageOrientation(_ image: inout CIImage) {
        // Rotation
        switch orientation {
        case .left: image = image.oriented(.down)
        case .up: image = image.oriented(.right)
        case .down: image = image.oriented(.left)
        default: break
        }
        
        // Scale
        let scaleX = drawableSize.width / image.extent.width
        let scaleY = drawableSize.height / image.extent.height
        let scale = max(scaleX, scaleY)
        image = image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        
        // Get center of image
        image = image.cropped(to: CGRect(
                                x: (image.extent.width - drawableSize.width) / 2,
                                y: (image.extent.height - drawableSize.height) / 2,
                                width: drawableSize.width,
                                height: drawableSize.height))
    }
    
    @objc private func displayLinkUpdated(link: CADisplayLink) {
        let time = output.itemTime(forHostTime: CACurrentMediaTime())
        guard output.hasNewPixelBuffer(forItemTime: time),
              let pixbuf = output.copyPixelBuffer(forItemTime: time, itemTimeForDisplay: nil) else { return }
        
        var baseImg = CIImage(cvImageBuffer: pixbuf, options: [CIImageOption.applyOrientationProperty : true])
        fixImageOrientation(&baseImg)
        image = content.createCGImage(baseImg, from: baseImg.extent)
    }
    
    override func draw(_ rect: CGRect) {
        guard let drawable = currentDrawable, let image = image else {
            return
        }
        let commandBuffer = commandQueue?.makeCommandBuffer()
        
        // Drawing texture
        let drawingTexture = drawable.texture
        // Image texture
        do {
            try imageTexture = MTKTextureLoader(device: device!).newTexture(cgImage: image, options: nil)
        } catch {
            print(error)
        }
        
        // Blur Parameters
        blurParameters = .init(
            radius: blurRadius,
            originX: Float((squareOrigin.x * pointToPixelScale) + squareSide),
            originY: Float((squareOrigin.y * pointToPixelScale) + squareSide))
        
        // Thread Groups
        let width = computePipelineState!.threadExecutionWidth
        let height = computePipelineState!.maxTotalThreadsPerThreadgroup / width
        let threadsPerThreadgroup = MTLSizeMake(width, height, 1)
        let threadgroupsPerGrid = MTLSize(width: (imageTexture.width + width - 1) / width,
                                          height: (imageTexture.height + height - 1) / height,
                                          depth: 1)
        
        // Encoders
        func makeAndUseComputeEncoders() {
            let computeEncoder = commandBuffer?.makeComputeCommandEncoder()
            computeEncoder?.setComputePipelineState(computePipelineState)
            computeEncoder?.setTexture(imageTexture, index: 0)
            computeEncoder?.setTexture(drawingTexture, index: 1)
            computeEncoder?.setBytes(&blurParameters, length: MemoryLayout<BlurParameters>.size, index: 0)
            computeEncoder?.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
            computeEncoder?.endEncoding()
            
            let computeEncoder2 = commandBuffer?.makeComputeCommandEncoder()
            computeEncoder2?.setComputePipelineState(computePipelineState2)
            computeEncoder2?.setTexture(drawable.texture, index: 0)
            computeEncoder2?.setTexture(drawingTexture, index: 1)
            computeEncoder2?.setBytes(&blurParameters, length: MemoryLayout<BlurParameters>.size, index: 0)
            computeEncoder2?.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
            computeEncoder2?.endEncoding()
            
            let computeEncoder3 = commandBuffer?.makeComputeCommandEncoder()
            computeEncoder3?.setComputePipelineState(computePipelineState3)
            computeEncoder3?.setTexture(imageTexture, index: 0)
            computeEncoder3?.setTexture(drawingTexture, index: 1)
            computeEncoder3?.setBytes(&blurParameters, length: MemoryLayout<BlurParameters>.size, index: 0)
            computeEncoder3?.dispatchThreadgroups(threadgroupsPerGrid, threadsPerThreadgroup: threadsPerThreadgroup)
            computeEncoder3?.endEncoding()
        }
        makeAndUseComputeEncoders()
        
        
        // Command Buffer
        commandBuffer?.present(drawable)
        commandBuffer?.commit()
    }
}
