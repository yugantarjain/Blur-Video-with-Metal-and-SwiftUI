//
//  Retrica_TaskApp.swift
//  Retrica-Task
//
//  Created by Yugantar Jain on 09/12/20.
//

import SwiftUI

@main
struct Retrica_TaskApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
